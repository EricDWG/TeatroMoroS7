/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.teatromoro;

import java.util.ArrayList;
import java.util.Scanner;
import teatromoro.Venta;

/**
 *
 * @author Eric Hidalgo Semana 7 moro
 */
public class TeatroMoro {
    static String nombreTeatro = "Teatro Moro";
    static int entradasDisponibles = 100;
    static double ingresosTotales = 0;

    static ArrayList<Venta> ventas = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion = 0;

        while (opcion != 5) {
            System.out.println("===== Teatro Moro - Menu de Opciones =====");
            System.out.println("1. Vender entrada");
            System.out.println("2. Ver resumen de ventas");
            System.out.println("3. Generar boletas");
            System.out.println("4. Ver ingresos totales");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1 -> venderEntrada();
                case 2 -> mostrarResumen();
                case 3 -> generarBoletas();
                case 4 -> System.out.println("Ingresos totales: $" + ingresosTotales);
                case 5 -> System.out.println("Gracias por su compra");
                default -> System.out.println("Opcion no valida.");
            }
        }
    }

    public static void venderEntrada() {
        String ubicacion = "";
        double precioBase = 0;
        double descuento = 0;
        boolean entradaValida = false;

        System.out.println("Ubicaciones: VIP, Platea, Balcon");
        System.out.print("Ingrese la ubicacion: ");
        ubicacion = sc.nextLine();

        if (ubicacion.equalsIgnoreCase("VIP")) {
            precioBase = 20000;
            entradaValida = true;
        } else if (ubicacion.equalsIgnoreCase("Platea")) {
            precioBase = 15000;
            entradaValida = true;
        } else if (ubicacion.equalsIgnoreCase("Balcon")) {
            precioBase = 10000;
            entradaValida = true;
        }

        if (!entradaValida) {
            System.out.println("Ubicacion no valida.");
            return;
        }

        System.out.print("Es estudiante? (s/n): ");
        String esEstudiante = sc.nextLine();
        System.out.print("Es tercera edad? (s/n): ");
        String esMayor = sc.nextLine();

        if (esEstudiante.equalsIgnoreCase("s")) {
            descuento = 0.10;
        } else if (esMayor.equalsIgnoreCase("s")) {
            descuento = 0.15;
        }

        double descuentoValor = precioBase * descuento;
        double precioFinal = precioBase - descuentoValor;

        Venta v = new Venta(ubicacion, precioBase, descuentoValor, precioFinal);
        ventas.add(v);
        ingresosTotales += precioFinal;
        entradasDisponibles--;

        System.out.println("Venta registrada correctamente.");
    }

    public static void mostrarResumen() {
        if (ventas.isEmpty()) {
            System.out.println("No hay ventas realizadas.");
        } else {
            for (Venta v : ventas) {
                System.out.println("Ubicacion: " + v.getUbicacion()
                    + " | Precio final: $" + v.getCostoFinal()
                    + " | Descuento: $" + v.getDescuentoAplicado());
            }
        }
    }

    public static void generarBoletas() {
        if (ventas.isEmpty()) {
            System.out.println("No hay boletas para mostrar.");
        } else {
            for (Venta v : ventas) {
                System.out.println("---------- BOLETA ----------");
                System.out.println("Teatro: " + nombreTeatro);
                System.out.println("Ubicacion: " + v.getUbicacion());
                System.out.println("Precio base: $" + v.getCostoBase());
                System.out.println("Descuento aplicado: $" + v.getDescuentoAplicado());
                System.out.println("Total a pagar: $" + v.getCostoFinal());
                System.out.println("Gracias por su compra");
                System.out.println("----------------------------");
            }
        }
    }
}
