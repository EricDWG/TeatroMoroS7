package teatromoro;

public class Venta {
    private final String ubicacion;
    private final double costoBase;
    private final double descuentoAplicado;
    private final double costoFinal;

    public Venta(String ubicacion, double costoBase, double descuentoAplicado, double costoFinal) {
        this.ubicacion = ubicacion;
        this.costoBase = costoBase;
        this.descuentoAplicado = descuentoAplicado;
        this.costoFinal = costoFinal;
    }

    public String getUbicacion() { return ubicacion; }
    public double getCostoBase() { return costoBase; }
    public double getDescuentoAplicado() { return descuentoAplicado; }
    public double getCostoFinal() { return costoFinal; }
}
